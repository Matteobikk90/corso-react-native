import { useState } from "react";
import {
  FlatList,
  Pressable,
  Text,
  TextInput,
  View,
  type ListRenderItemInfo,
} from "react-native";

type ToDoType = { id: string; title: string; done: boolean };

export function ToDo() {
  const [todos, setTodos] = useState<ToDoType[]>([]);
  const [inputText, setInputText] = useState("");

  const addTodo = () => {
    const title = inputText.trim();
    if (!title) return;

    setTodos((prev) => [
      ...prev,
      { id: String(Date.now()), title, done: false },
    ]);

    setInputText("");
  };

  return (
    <>
      <FlatList
        data={todos}
        keyExtractor={(item: ToDoType) => item.id}
        renderItem={({ item }: ListRenderItemInfo<ToDoType>) => (
          <View>
            <Text>{item.title}</Text>

            {/* onPress={removeTodo} */}
            <Pressable>
              <Text
                style={{
                  margin: "auto",
                  padding: 5,
                  backgroundColor: "red",
                  width: "auto",
                  color: "black",
                  borderRadius: 20,
                }}>
                RIMUOVI TODO - {item.title}
              </Text>
            </Pressable>
          </View>
        )}
      />
      {/* <FlatList /> */}

      <TextInput
        value={inputText}
        onChangeText={(text) => setInputText(text)}
        placeholder="Scrivi un task…"
        style={{ borderWidth: 1, padding: 10, borderRadius: 10 }}
      />

      <Pressable onPress={addTodo}>
        <Text
          style={{
            margin: "auto",
            padding: 20,
            backgroundColor: "blue",
            width: "auto",
            color: "white",
            borderRadius: 20,
          }}>
          AGGIUNGI TODO
        </Text>
      </Pressable>
    </>
  );
}
